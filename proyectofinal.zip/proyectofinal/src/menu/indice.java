/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package menu;

import RN.Rojinegros;
import avl.AVL;
import javax.swing.JPanel;
import avl.AVL;

/**
 *
 * @author theglox
 */
public class indice {
    int n;
 AVL avl = new AVL();
 Rojinegros rn = new Rojinegros();
  String Nrepetidos="";

    
 public int llenar(){
     int c=0,suma=0,aux;
  int[] numeros =new int[100];
  String[]numeros2= new String [100];
 
 // int []numeros = {7,48,78,20,12,62,34};

    for (int i=0; i < numeros.length; i++){
        numeros[i] = (int) (Math.random()*500);
    }
    //imprimiendo numeros
    for (int i=0; i < numeros.length; i++){
        numeros2[i]=Integer.toString(numeros[i]);
    }
  
    
       for(int i=0;i<numeros2.length;i++){
      for(int j=0;j<numeros2.length-1;j++){
	if(i!=j){
            if(numeros2[i].equals(numeros2[j])){// eliminamos su valor
                Nrepetidos += numeros2[i]+",";
		numeros2[i]=".";
               
            }
    }}}
   
 
     System.out.println("los numeros repetidos son ;"+Nrepetidos);
     for (int i=0; i < numeros.length; i++){
         System.out.print("i"+numeros[i]+",");}
     System.out.println("");
     for (int i=0; i < numeros.length; i++){
         System.out.print("S"+numeros2[i]+",");
        }
   
    
    for(int i = 0; i<numeros.length; i++){
        aux=avl.insAVL(numeros[i],c);
  
        
        System.out.println(avl.insAVL(numeros[i],c));
        suma=suma+aux;
        
    }    


            
            System.out.println("el numero de if fue en avl : " + c);
             
            
           

int resul;
rn.inicializar();



    for (int i=0; i < numeros.length; i++){
         avl.insAVL(numeros[i],c);
         rn.insertar(numeros[i]);
        rn.inorden(rn.Raiz());
              
                System.out.println(" ");
                rn.preorden(rn.Raiz());
                System.out.println(" ");
    }
     System.out.println("suma +"+suma);//*"
    
 
    return suma*2;
    
 }
 int c1;
 
 
 
 public int retirar (int numero){
     
     c1=0;
    int nel=avl.retirarAVL(numero,0);
    c1=avl.getC1();
     System.out.println("retirar--"+avl.getC1());
        return nel; }

    public int getC1() {
        return c1;
    }
 public int ifes(){
     
 int  c = rn.getInsert();
            System.out.println("el numero de if fue : " + c);
            return c;
 }
 public String numerosr (){
     
 return Nrepetidos;}
  public JPanel getdibujo() {
        return  avl.getdibujo();
    }
   public JPanel getdibujorn() {
        return  rn.getdibujorn();
    }
}
